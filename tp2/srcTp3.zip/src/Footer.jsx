import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js'

function Footer() {
    return (

        <footer class="bg-info text-center text-lg-start fixed-bottom">
        <div class="text-center p-3" style={{backgroundColor: "orange"}}>
          © 2024 Copyright:
          
        </div>
      </footer>   



    );

} export default Footer